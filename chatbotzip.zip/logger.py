def log_chat(session_id, user_input, bot_response):
    with open("chat_log.txt", "a") as f:
        f.write(f"[{session_id}] You: {user_input}\n")
        f.write(f"[{session_id}] Bot: {bot_response}\n\n")
