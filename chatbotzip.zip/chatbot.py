import os
import json
import random

CRISIS_KEYWORDS = [
    "suicide", "kill myself", "end my life", "hurt myself", "self-harm", "die", "give up"
]

SAFETY_MESSAGE = (
    "I'm really sorry you're feeling this way. 💔\n"
    "Please reach out to a mental health professional or contact a helpline immediately.\n"
    "📞 Nepal Mental Health Helpline (MHAA): 9851171077\n"
    "📞 Suicide Prevention Helpline Nepal: 16600122212\n"
    "You're not alone — help is available and you deserve support. ❤️"
)

def contains_crisis_keywords(message):
    message = message.lower()
    return any(keyword in message for keyword in CRISIS_KEYWORDS)

def load_responses(file_path="data/responses.json"):
    if not os.path.exists(file_path):
        print(f"Warning: Responses file not found at {file_path}")
        return {}
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)

def detect_emotion(message):
    message = message.lower()
    emotion_keywords = {
    "happiness": ["happy", "joy", "excited", "good", "great", "fantastic"],
    "sadness": ["sad", "cry", "depressed", "unhappy"],
    "anxiety": ["anxious", "panic", "worried", "nervous"],
    "stress": ["stressed", "overwhelmed", "pressure"],
    "loneliness": ["lonely", "alone", "isolated"],
    "hopelessness": ["hopeless", "give up", "no way out", "nothing matters"],
    "anger": ["angry", "mad", "frustrated", "irritated"],
    "exhaustion": ["tired", "exhausted", "burnt out", "fatigued"],
    "grief": ["grief", "loss", "mourning", "bereaved"],
    "numbness": ["numb", "empty", "detached", "disconnected"]
}

    

    for emotion, keywords in emotion_keywords.items():
        if any(keyword in message for keyword in keywords):
            return emotion
    return "default"

def get_response(user_input, categorized_responses):
    # 🔴 Crisis check first
    if contains_crisis_keywords(user_input):
        return SAFETY_MESSAGE, "crisis"

    emotion = detect_emotion(user_input)
    responses = categorized_responses.get(emotion) or categorized_responses.get("default")

    if responses:
        return random.choice(responses), emotion
    else:
        return "I'm here to support you.", emotion

if __name__ == "__main__":
    responses = load_responses()
    print("Chatbot: Hi, I'm here to listen. How are you feeling today?")

    while True:
        user_input = input("You: ")
        if user_input.lower() in ["quit", "exit"]:
            print("Chatbot: Take care of yourself. 💙")
            break

        reply, detected = get_response(user_input, responses)
        print(f"(Detected Emotion: {detected})")
        print(f"Chatbot: {reply}")
