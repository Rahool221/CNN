CRISIS_KEYWORDS = [
    "sucide", "kill myself", "end my life", "hurt myself", "self-harm", "die", "give up"
]

SAFETY_MESSAGE = (
    "I'm really sorry you're feeling this way. 💔 "
    "Please reach out to a mental health professional or contact a helpline. "
    "You're not alone and there is help available."
    "Nepal Mental Health Helpline (MHAA): 9851171077"
    "Suicide Prevention Helpline Nepal: 16600122212"
    
)

def contains_crisis_keywords(message):
    message = message.lower()
    return any(keyword in message for keyword in CRISIS_KEYWORDS)
