# Import the uuid module to generate a unique session ID for each user interaction
import uuid

# Import functions to load predefined responses and generate responses based on user input
from chatbot import load_responses, get_response

# Import function to check for crisis-related keywords and the predefined safety message
from crisis import contains_crisis_keywords, SAFETY_MESSAGE

# Import the logging function to save each chat interaction to a log file
from logger import log_chat

# Main function that runs the chatbot loop
def main():
    # Load predefined emotion-based responses from a JSON file
    responses = load_responses()

    # Generate a unique session ID for the chat session
    session_id = str(uuid.uuid4())

    # Greet the user
    print("🤖 Hello! I'm your mental health assistant. Type 'exit' to end the conversation.\n")

    # Start a loop to keep the conversation going until the user exits
    while True:
        # Take input from the user and remove leading/trailing spaces
        user_input = input("You: ").strip()

        # If user types 'exit', end the conversation politely
        if user_input.lower() == "exit":
            print("🤖 Take care! Remember, you're not alone. 💚")
            break

        # Check if the input contains any crisis keywords (like self-harm, suicide, etc.)
        if contains_crisis_keywords(user_input):
            # If a crisis is detected, display a supportive message
            print("🤖", SAFETY_MESSAGE)
            # Log both the user input and bot's safety message
            log_chat(session_id, user_input, SAFETY_MESSAGE)
            continue

        # Otherwise, get a suitable response using the emotion-aware response generator
        response = get_response(user_input, responses)
        # Print the chatbot's response
        print("🤖", response)

        # Log this user-bot interaction for session tracking or analysis
        log_chat(session_id, user_input, response)

# Run the main chatbot function only when this script is executed directly
if __name__ == "__main__":
    main()
