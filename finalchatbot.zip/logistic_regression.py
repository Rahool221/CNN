import numpy as np  # Import numpy for array and math operations

class LogisticRegressionScratch:
    def __init__(self, lr=0.1, n_iters=1000):
        self.lr = lr                # Learning rate for gradient descent
        self.n_iters = n_iters      # Number of iterations for training
        self.weights = None         # Weight matrix for features to classes
        self.bias = None            # Bias vector for each class
        self.n_classes = None       # Number of classes (emotion categories)
        self.label_to_index = None  # Mapping from original labels to zero-based indices

    def _softmax(self, z):
        # Numerically stable softmax function
        exp = np.exp(z - np.max(z, axis=1, keepdims=True))  # subtract max for stability
        return exp / exp.sum(axis=1, keepdims=True)        # normalize to probabilities per row

    def _map_labels(self, y):
        # Map non-zero-based labels to zero-based indices for internal processing
        unique_labels = sorted(set(y))  # Get sorted unique labels
        self.label_to_index = {label: idx for idx, label in enumerate(unique_labels)}  # Create mapping
        y_mapped = np.array([self.label_to_index[label] for label in y])  # Map y to zero-based indices
        return y_mapped

    def _one_hot(self, y):
        # Convert zero-based label array into one-hot encoded matrix
        unique_labels = sorted(set(y))
        num_classes = len(unique_labels)
        one_hot = np.zeros((len(y), num_classes))  # Initialize zero matrix
        for i, val in enumerate(y):
            if val >= num_classes or val < 0:
                raise ValueError(f"Label {val} is out of range 0-{num_classes-1}")
            one_hot[i, val] = 1  # Set 1 in the column corresponding to class
        return one_hot

    def fit(self, X, y):
        # Train the logistic regression model using gradient descent

        y_mapped = self._map_labels(y)  # Ensure labels are zero-based indices

        n_samples, n_features = X.shape
        self.n_classes = len(np.unique(y_mapped))  # Number of emotion classes

        # Initialize weights and bias to zeros
        self.weights = np.zeros((n_features, self.n_classes))
        self.bias = np.zeros(self.n_classes)

        y_one_hot = self._one_hot(y_mapped)  # One-hot encode labels

        for _ in range(self.n_iters):  # Loop for number of iterations
            linear_model = np.dot(X, self.weights) + self.bias  # Compute linear logits
            y_pred = self._softmax(linear_model)                # Apply softmax for probabilities

            # Compute gradients of loss wrt weights and bias
            dw = (1 / n_samples) * np.dot(X.T, (y_pred - y_one_hot))
            db = (1 / n_samples) * np.sum(y_pred - y_one_hot, axis=0)

            # Update weights and bias using gradient descent
            self.weights -= self.lr * dw
            self.bias -= self.lr * db

    def predict(self, X):
        # Predict emotion class labels for input features X

        linear_model = np.dot(X, self.weights) + self.bias  # Calculate logits
        y_pred = self._softmax(linear_model)                # Calculate class probabilities
        y_indices = np.argmax(y_pred, axis=1)               # Get predicted class indices (max probability)

        # Convert zero-based indices back to original labels if mapping exists
        if self.label_to_index is not None:
            index_to_label = {idx: label for label, idx in self.label_to_index.items()}  # Reverse mapping
            y_labels = np.array([index_to_label[idx] for idx in y_indices])               # Map back
            return y_labels
        else:
            return y_indices
