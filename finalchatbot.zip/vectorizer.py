import numpy as np  # For numerical array operations
import math  # For logarithm calculation

class SimpleVectorizer:
    def __init__(self):
        self.vocab = {}  # Dictionary mapping word -> index in feature vector
        self.idf = {}  # Dictionary storing Inverse Document Frequency for each word

    def fit_transform(self, texts):
        # Build vocabulary with document frequency counts
        word_doc_freq = {}  # Counts of documents each word appears in
        for text in texts:
            words = set(text.lower().split())  # Unique words in this document (text)
            for word in words:
                # Increment count of documents containing this word
                word_doc_freq[word] = word_doc_freq.get(word, 0) + 1

        # Create vocabulary: assign each word a unique index
        self.vocab = {word: idx for idx, word in enumerate(word_doc_freq)}
        N = len(texts)  # Total number of documents

        # Calculate IDF (Inverse Document Frequency) for each word
        # IDF = log(total_docs / (docs_containing_word + 1))
        self.idf = {
            word: math.log(N / (df + 1)) for word, df in word_doc_freq.items()
        }

        # Return TF-IDF vectors for the input texts
        return self._transform_tfidf(texts)

    def transform(self, texts):
        # Transform new texts into TF-IDF vectors using the existing vocab and IDF
        return self._transform_tfidf(texts)

    def _transform_tfidf(self, texts):
        # Create zero matrix to hold TF-IDF vectors
        vectors = np.zeros((len(texts), len(self.vocab)))

        for i, text in enumerate(texts):
            word_count = {}  # Counts of words in the current document
            words = text.lower().split()  # Tokenize text by splitting on whitespace
            for word in words:
                # Count only words present in the vocabulary
                if word in self.vocab:
                    word_count[word] = word_count.get(word, 0) + 1

            # Calculate TF-IDF for each word in the document
            for word, count in word_count.items():
                idx = self.vocab[word]  # Index of word in feature vector
                tf = count / len(words)  # Term Frequency = count / total words in doc
                idf = self.idf[word]  # Inverse Document Frequency from stored values
                vectors[i, idx] = tf * idf  # TF-IDF = TF * IDF

        return vectors  # Return matrix of TF-IDF feature vectors
