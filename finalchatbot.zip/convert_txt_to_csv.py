import csv
import os

# Emotion to numeric label mapping
emotion_map = {
    "sadness": 0,
    "fear": 1,        # map fear to anxiety (1)
    "anger": 3,
    "joy": 6,         # map joy to happiness (6)
    "love": 6,
    "surprise": 6     # optional, map surprise to happiness (6)
}

input_folder = "archive"
output_csv = "emotion_data.csv"

def process_file(file_path, writer):
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue

            # Assuming tab-separated: "text \t emotion"
            if "\t" in line:
                text, emotion = line.split("\t")
            elif "," in line:
                # fallback to comma separated if tab not found
                text, emotion = line.split(",", 1)
            else:
                print(f"Skipping malformed line: {line}")
                continue

            emotion = emotion.lower()
            if emotion in emotion_map:
                label = emotion_map[emotion]
                writer.writerow([text.strip(), label])
            else:
                # skip if emotion not in mapping
                continue

def convert_all_txt_to_csv():
    with open(output_csv, 'w', newline='', encoding='utf-8') as outfile:
        writer = csv.writer(outfile)
        writer.writerow(["text", "label"])  # CSV header

        for filename in ["train.txt", "test.txt", "val.txt"]:
            file_path = os.path.join(input_folder, filename)
            if os.path.exists(file_path):
                print(f"Processing {file_path}...")
                process_file(file_path, writer)
            else:
                print(f"File not found: {file_path}")

    print(f"\nConversion complete. Data saved to '{output_csv}'")

if __name__ == "__main__":
    convert_all_txt_to_csv()
