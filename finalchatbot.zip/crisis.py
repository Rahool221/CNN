CRISIS_KEYWORDS = [
    "suicide", "kill myself", "end my life", "hurt myself", "self-harm", "die", "give up","I want to end my life.","i quit",
    "I feel like I can't go on anymore",
    "I'm thinking about suicide",
    "I just want the pain to stop",
    "There's no reason for me to live",
    "I can't take this anymore",
    "I'm done with everything",
    "I feel hopeless and want to disappear",
    "No one would miss me if I were gone",
    "I'm better off dead",
    "I want to give up completely",
    "Everything feels meaningless",
    "I feel like a burden to everyone",
    "I don’t belong in this world",
    "I wish I could just vanish",
    "I feel trapped with no way out",
    "Death feels like the only escape",
    "I'm tired of pretending I’m okay",
    "I keep thinking about ending it all",
    "Life has no purpose anymore"
]

SAFETY_MESSAGE = (
    "I'm really sorry you're feeling this way. 💔 "
    "Please reach out to a mental health professional or contact a helpline. "
    "You're not alone and there is help available."
    "Nepal Mental Health Helpline (MHAA): 9851171077"
    "Suicide Prevention Helpline Nepal: 16600122212"
    
)

def contains_crisis_keywords(message):
    message = message.lower()
    return any(keyword.lower() in message for keyword in CRISIS_KEYWORDS)

