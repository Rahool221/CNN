# # import csv
# # import random
# # import json
# # from vectorizer import SimpleVectorizer
# # from logistic_regression import LogisticRegressionScratch
# # import crisis

# # # Define greetings keywords and responses
# # GREETINGS_KEYWORDS = [
# #     "hi", "hello", "hlo", "hey", "greetings",
# #     "good morning", "good afternoon", "good evening", "how are you"
# # ]

# # GREETINGS_RESPONSES = [
# #     "Hello! How can I help you today?",
# #     "Hi there! I'm here to listen.",
# #     "Hey! What's on your mind?",
# #     "Greetings! How are you feeling today?",
# #     "Hello! I'm here if you want to talk."
# # ]

# # def load_data(file_path):
# #     texts = []
# #     labels = []
# #     with open(file_path, mode='r', encoding='utf-8') as f:
# #         reader = csv.DictReader(f)
# #         for row in reader:
# #             texts.append(row['text'].strip())
# #             labels.append(int(row['label'].strip()))
# #     return texts, labels

# # def is_greeting(message):
# #     message = message.lower().strip()
# #     return message in GREETINGS_KEYWORDS

# # def get_response(predicted_emotion, responses):
# #     emotion_key = predicted_emotion.lower()
# #     if emotion_key in responses:
# #         return random.choice(responses[emotion_key])
# #     elif "default" in responses:
# #         return random.choice(responses["default"])
# #     else:
# #         return "I'm here for you."

# # def main():
# #     filename = "emotion_data.csv"
# #     responses_file = "responses.json"

# #     # Load chatbot responses JSON
# #     with open(responses_file, 'r', encoding='utf-8') as f:
# #         responses = json.load(f)

# #     # Load dataset
# #     texts, labels = load_data(filename)
# #     print(f"Loaded {len(texts)} records from {filename}")

# #     from sklearn.model_selection import train_test_split
# #     from sklearn.metrics import accuracy_score

# #     # Split into train/test sets
# #     X_train_texts, X_test_texts, y_train, y_test = train_test_split(
# #         texts, labels, test_size=0.3, random_state=42
# #     )

# #     # Vectorize text data
# #     vectorizer = SimpleVectorizer()
# #     X_train = vectorizer.fit_transform(X_train_texts)
# #     X_test = vectorizer.transform(X_test_texts)

# #     # Train logistic regression model
# #     model = LogisticRegressionScratch(lr=0.1, n_iters=1000)
# #     model.fit(X_train, y_train)

# #     # Evaluate
# #     y_pred = model.predict(X_test)
# #     print("Test Accuracy:", accuracy_score(y_test, y_pred))

# #     # Label-to-emotion mapping
# #     emotions = {
# #         0: "sadness",
# #         1: "anxiety",
# #         2: "stress",
# #         3: "anger",
# #         4: "exhaustion",
# #         5: "loneliness",
# #         6: "happiness"
# #     }

# #     print("\nChatbot ready. Type your message (type 'exit' to quit).")

# #     while True:
# #         user_input = input("You: ").strip()
# #         if user_input.lower() == "exit":
# #             print("Chatbot: Take care. I'm always here if you need me. 💙")
# #             break

# #         # Check for greetings
# #         if is_greeting(user_input):
# #             print("Chatbot:", random.choice(GREETINGS_RESPONSES))
# #             continue

# #         # Check for crisis keywords
# #         if crisis.contains_crisis_keywords(user_input):
# #             print("Chatbot:", crisis.SAFETY_MESSAGE)
# #             continue

# #         # Vectorize and predict emotion
# #         vec = vectorizer.transform([user_input])
# #         pred_label = model.predict(vec)[0]
# #         predicted_emotion = emotions.get(pred_label, "default")

# #         # Generate response based on emotion
# #         reply = get_response(predicted_emotion, responses)

# #         print(f"Chatbot (Predicted emotion: {predicted_emotion}): {reply}")

# # if __name__ == "__main__":
# #     main()


# import csv
# import json
# import random
# from vectorizer import SimpleVectorizer
# from logistic_regression import LogisticRegressionScratch
# import crisis

# # ---------------- 1. LOAD DATA & TRAIN MODEL ----------------
# def load_and_train():
#     filename = "emotion_data.csv"       # Path to dataset CSV file
#     responses_file = "responses.json"   # Path to chatbot responses JSON file

#     # Load the JSON file containing categorized chatbot responses
#     with open(responses_file, 'r', encoding='utf-8') as f:
#         responses = json.load(f)

#     texts, labels = [], []
#     with open(filename, mode='r', encoding='utf-8') as f:
#         reader = csv.DictReader(f)
#         for row in reader:
#             texts.append(row['text'].strip())
#             labels.append(int(row['label'].strip()))

#     from sklearn.model_selection import train_test_split
#     X_train_texts, _, y_train, _ = train_test_split(
#         texts, labels, test_size=0.3, random_state=42
#     )

#     vectorizer = SimpleVectorizer()
#     X_train = vectorizer.fit_transform(X_train_texts)

#     model = LogisticRegressionScratch(lr=0.1, n_iters=1000)
#     model.fit(X_train, y_train)

#     emotions = {
#         0: "sadness",
#         1: "anxiety",
#         2: "stress",
#         3: "anger",
#         4: "exhaustion",
#         5: "loneliness",
#         6: "happiness"
#     }

#     return model, vectorizer, emotions, responses

# # ---------------- 2. GREETING CHECK ----------------
# def is_greeting(message):
#     greetings = ["hi", "hello", "hlo", "hey", "hii", "hiii", "greetings",
#                  "good morning", "good afternoon", "good evening", "how are you"]
#     message = message.lower().strip()
#     return any(message.startswith(greet) or greet in message for greet in greetings)

# GREETINGS_RESPONSES = [
#     "Hello! How can I help you today?",
#     "Hi there! I'm here to listen.",
#     "Hey! What's on your mind?",
#     "Greetings! How are you feeling today?",
#     "Hello! I'm here if you want to talk."
# ]

# # ---------------- 3. GET RESPONSE ----------------
# def get_response(predicted_emotion, responses):
#     emotion_key = predicted_emotion.lower()
#     if emotion_key in responses:
#         return random.choice(responses[emotion_key])
#     elif "default" in responses:
#         return random.choice(responses["default"])
#     else:
#         return "I'm here for you."

# # ---------------- 4. MAIN CHATBOT LOOP ----------------
# if __name__ == "__main__":
#     print("Training model, please wait...")
#     model, vectorizer, emotions, responses = load_and_train()
#     print("Chatbot: Hi, I'm here to listen. How are you feeling today?")
#     print("Type 'exit' to quit.\n")

#     while True:
#         user_input = input("You: ").strip()
#         if user_input.lower() in ["quit", "exit"]:
#             print("Chatbot: Take care of yourself. 💙")
#             break

#         # Greeting check
#         if is_greeting(user_input):
#             print("Chatbot:", random.choice(GREETINGS_RESPONSES))
#             continue

#         # Crisis check
#         if hasattr(crisis, "contains_crisis_keywords") and crisis.contains_crisis_keywords(user_input):
#             print("Chatbot:", crisis.SAFETY_MESSAGE)
#             continue

#         # Emotion prediction
#         user_vector = vectorizer.transform([user_input])
#         pred_label = model.predict(user_vector)[0]
#         predicted_emotion = emotions.get(pred_label, "default")

#         # Get response
#         reply = get_response(predicted_emotion, responses)
#         print(f"Chatbot (Predicted emotion: {predicted_emotion}): {reply}")


import csv
import json
import random
from vectorizer import SimpleVectorizer
from logistic_regression import LogisticRegressionScratch
import crisis

# ---------------- 1. LOAD DATA & TRAIN MODEL ----------------
def load_and_train():
    """
    Loads the dataset and responses, trains the logistic regression model, 
    and returns the model, vectorizer, emotion map, and response dictionary.
    """
    filename = "emotion_data.csv"       # Path to dataset CSV file
    responses_file = "responses.json"   # Path to chatbot responses JSON file

    # Load chatbot responses JSON
    with open(responses_file, 'r', encoding='utf-8') as f:
        responses = json.load(f)

    texts, labels = [], []
    with open(filename, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            texts.append(row['text'].strip())
            labels.append(int(row['label'].strip()))

    # Split training data
    from sklearn.model_selection import train_test_split
    X_train_texts, _, y_train, _ = train_test_split(
        texts, labels, test_size=0.3, random_state=42
    )

    # Vectorize
    vectorizer = SimpleVectorizer()
    X_train = vectorizer.fit_transform(X_train_texts)

    # Train model
    model = LogisticRegressionScratch(lr=0.1, n_iters=1000)
    model.fit(X_train, y_train)

    # Map numeric labels to emotions
    emotions = {
        0: "sadness",
        1: "anxiety",
        2: "stress",
        3: "anger",
        4: "exhaustion",
        5: "loneliness",
        6: "happiness",
        7: "crisis"  # Suicidal/crisis messages
    }

    return model, vectorizer, emotions, responses

# ---------------- 2. GREETING CHECK ----------------
def is_greeting(message):
    """
    Returns True if the message is a greeting.
    """
    greetings = ["hi", "hello", "hlo", "hey", "hii", "hiii", "greetings",
                 "good morning", "good afternoon", "good evening", "how are you"]
    message = message.lower().strip()
    return any(message.startswith(greet) or greet in message for greet in greetings)

GREETINGS_RESPONSES = [
    "Hello! How can I help you today?",
    "Hi there! I'm here to listen.",
    "Hey! What's on your mind?",
    "Greetings! How are you feeling today?",
    "Hello! I'm here if you want to talk."
]

# ---------------- 3. GET RESPONSE ----------------
def get_response(predicted_emotion, responses):
    """
    Returns a random chatbot response based on the predicted emotion.
    Crisis messages always return the safety message.
    """
    if predicted_emotion == "crisis":
        return crisis.SAFETY_MESSAGE
    emotion_key = predicted_emotion.lower()
    if emotion_key in responses:
        return random.choice(responses[emotion_key])
    elif "default" in responses:
        return random.choice(responses["default"])
    else:
        return "I'm here for you."

# ---------------- 4. MAIN CHATBOT LOOP ----------------
if __name__ == "__main__":
    print("Training model, please wait...")
    model, vectorizer, emotions, responses = load_and_train()
    print("Chatbot: Hi, I'm here to listen. How are you feeling today?")
    print("Type 'exit' to quit.\n")

    while True:
        user_input = input("You: ").strip()
        if user_input.lower() in ["quit", "exit"]:
            print("Chatbot: Take care of yourself. 💙")
            break

        # Greeting check
        if is_greeting(user_input):
            print("Chatbot:", random.choice(GREETINGS_RESPONSES))
            continue

        # Crisis check (keyword-based)
        if hasattr(crisis, "contains_crisis_keywords") and crisis.contains_crisis_keywords(user_input):
            print("Chatbot:", crisis.SAFETY_MESSAGE)
            continue

        # Emotion prediction
        user_vector = vectorizer.transform([user_input])
        pred_label = model.predict(user_vector)[0]
        predicted_emotion = emotions.get(pred_label, "default")

        # Crisis handling for predicted label 7
        if predicted_emotion == "crisis":
            print("Chatbot:", crisis.SAFETY_MESSAGE)
            continue

        # Generate response
        reply = get_response(predicted_emotion, responses)
        print(f"Chatbot (Predicted emotion: {predicted_emotion}): {reply}")
