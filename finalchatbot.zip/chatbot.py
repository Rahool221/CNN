import json          # For loading JSON files (responses)
import random        # To select random responses
from vectorizer import SimpleVectorizer          # Custom vectorizer to convert text to features
from logistic_regression import LogisticRegressionScratch  # Custom logistic regression model

# Load responses from a JSON file
def load_responses(file_path="responses.json"):
    with open(file_path, "r") as f:
        return json.load(f)   # Return dictionary of categorized chatbot responses

# Load model and vectorizer (train model if needed)
def load_model():
    from generate_emotion_csv import filename   # Import dataset filename
    from main import load_data                   # Import function to load text-label pairs
    from sklearn.model_selection import train_test_split

    # Load texts and labels from dataset
    texts, labels = load_data(filename)

    # Split data into training and test sets (we only use training here)
    X_train_texts, _, y_train, _ = train_test_split(
        texts, labels, test_size=0.3, random_state=42
    )

    vectorizer = SimpleVectorizer()                 # Initialize text vectorizer
    X_train = vectorizer.fit_transform(X_train_texts)   # Fit and transform training texts

    model = LogisticRegressionScratch()             # Initialize logistic regression model
    model.fit(X_train, y_train)                       # Train model on vectorized texts and labels

    return model, vectorizer   # Return trained model and vectorizer for prediction

# Predict emotion index from user input text
def detect_emotion(text, model, vectorizer):
    vec = vectorizer.transform([text])     # Vectorize input text
    pred = model.predict(vec)[0]            # Predict emotion label index
    return pred

# Get chatbot response based on detected emotion
def get_response(user_input, responses, model, vectorizer):
    emotion_index = detect_emotion(user_input, model, vectorizer)   # Detect emotion index
    emotions = {       # Map numeric indices to emotion labels
        0: "sadness", 1: "anxiety", 2: "stress", 3: "anger",
        4: "exhaustion", 5: "loneliness", 6: "happiness"
    }
    emotion = emotions.get(emotion_index, "default")   # Get emotion label or default
    # Return a random response from the emotion category or default category
    return random.choice(responses.get(emotion, responses.get("default", ["I'm here for you."])))

# Main chatbot loop to interact with user in console
def run_chatbot():
    responses = load_responses()    # Load chatbot responses from JSON
    model, vectorizer = load_model()  # Load or train emotion detection model and vectorizer

    print("Chatbot is ready. Type 'exit' to quit.")  # Inform user how to quit
    while True:
        user_input = input("You: ")   # Take user input from console
        if user_input.lower() == "exit":   # Exit condition
            break
        reply = get_response(user_input, responses, model, vectorizer)  # Get bot response
        print("Bot:", reply)   # Print chatbot reply

# Run the chatbot if this script is executed directly
if __name__ == "__main__":
    run_chatbot()
