
# import csv              # Import csv module to read CSV files
# import json             # Import json module to load JSON files
# import random           # Import random module to select random responses
# from vectorizer import SimpleVectorizer          # Import custom text vectorizer
# from logistic_regression import LogisticRegressionScratch  # Import custom logistic regression model
# import crisis           # Import crisis detection module for crisis keywords and messages

# # Load data and train model only once when app starts, cache the result for faster reloads
# @st.cache(allow_output_mutation=True)
# def load_and_train():
#     filename = "emotion_data.csv"       # Path to dataset CSV file
#     responses_file = "responses.json"   # Path to chatbot responses JSON file

#     # Load the JSON file containing categorized chatbot responses
#     with open(responses_file, 'r', encoding='utf-8') as f:
#         responses = json.load(f)

#     texts = []    # List to store input texts from dataset
#     labels = []   # List to store corresponding emotion labels

#     # Open CSV dataset and read each row into texts and labels lists
#     with open(filename, mode='r', encoding='utf-8') as f:
#         reader = csv.DictReader(f)
#         for row in reader:
#             texts.append(row['text'].strip())            # Append cleaned text
#             labels.append(int(row['label'].strip()))     # Append label as int

#     # Import train_test_split to split data into training and testing sets
#     from sklearn.model_selection import train_test_split

#     # Split data: 70% training, 30% testing, with fixed random seed for reproducibility
#     X_train_texts, X_test_texts, y_train, y_test = train_test_split(
#         texts, labels, test_size=0.3, random_state=42
#     )

#     vectorizer = SimpleVectorizer()          # Initialize the custom vectorizer
#     X_train = vectorizer.fit_transform(X_train_texts)  # Fit vectorizer on train data and transform

#     model = LogisticRegressionScratch(lr=0.1, n_iters=1000)  # Initialize logistic regression model
#     model.fit(X_train, y_train)                # Train the model on vectorized training data

#     # Mapping numeric labels to emotion category names
#     emotions = {
#         0: "sadness",
#         1: "anxiety",
#         2: "stress",
#         3: "anger",
#         4: "exhaustion",
#         5: "loneliness",
#         6: "happiness"
#     }

#     # Return the trained model, vectorizer, emotion label map, and responses dictionary
#     return model, vectorizer, emotions, responses

# # Load and train model on app startup
# model, vectorizer, emotions, responses = load_and_train()

# # Function to detect if user input is a greeting
# def is_greeting(message):
#     greetings = ["hi", "hello", "hlo", "hey", "greetings",
#                  "good morning", "good afternoon", "good evening", "how are you"]
#     message = message.lower().strip()             # Normalize input text
#     return any(greet in message for greet in greetings)  # Check if any greeting keyword is present

# # Predefined chatbot responses for greetings
# GREETINGS_RESPONSES = [
#     "Hello! How can I help you today?",
#     "Hi there! I'm here to listen.",
#     "Hey! What's on your mind?",
#     "Greetings! How are you feeling today?",
#     "Hello! I'm here if you want to talk."
# ]

# # Function to get chatbot response based on predicted emotion
# def get_response(predicted_emotion, responses):
#     emotion_key = predicted_emotion.lower()      # Normalize emotion key
#     if emotion_key in responses:
#         return random.choice(responses[emotion_key])   # Return random response from detected emotion category
#     elif "default" in responses:
#         return random.choice(responses["default"])     # Fallback to default responses
#     else:
#         return "I'm here for you."                       # Fallback message if no responses available

# st.title("Mental Health Chatbot with Emotion Detection")  # Set the title of the web app

# # Text input widget for user message
# user_input = st.text_input("Type your message:")

# if user_input:  # When user inputs a message
#     if is_greeting(user_input):  # Check if input is a greeting
#         st.write(random.choice(GREETINGS_RESPONSES))   # Show a random greeting response
#     elif crisis.contains_crisis_keywords(user_input):  # Check for crisis keywords
#         st.write(crisis.SAFETY_MESSAGE)               # Show safety message if crisis detected
#     else:
#         vec = vectorizer.transform([user_input])      # Vectorize user input text
#         pred_label = model.predict(vec)[0]             # Predict emotion label using model
#         predicted_emotion = emotions.get(pred_label, "default")  # Map label to emotion name
#         reply = get_response(predicted_emotion, responses)      # Get chatbot response for detected emotion
#         st.write(f"**Predicted emotion:** {predicted_emotion}")  # Display predicted emotion
#         st.write(f"**Chatbot:** {reply}")                         # Display chatbot reply





import csv
import json
import random
import os

# Assuming these custom modules are available in the same directory
from vectorizer import SimpleVectorizer
from logistic_regression import LogisticRegressionScratch
from crisis import contains_crisis_keywords, SAFETY_MESSAGE

# This function loads the data and trains the model.
# The @st.cache decorator from the web app has been removed.
def load_and_train():
    """
    Loads data, trains the emotion detection model, and returns
    the trained model, vectorizer, emotion map, and responses.
    """
    filename = "emotion_data.csv"
    responses_file = "responses.json"

    # Check for required files
    if not os.path.exists(filename) or not os.path.exists(responses_file):
        raise FileNotFoundError(f"Missing one or more required files: {filename}, {responses_file}. Please ensure they are in the same directory.")

    # Load the JSON file containing categorized chatbot responses
    with open(responses_file, 'r', encoding='utf-8') as f:
        responses = json.load(f)

    texts = []
    labels = []

    # Open CSV dataset and read each row
    with open(filename, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            texts.append(row['text'].strip())
            labels.append(int(row['label'].strip()))

    # Import train_test_split from scikit-learn
    from sklearn.model_selection import train_test_split

    # Split data into training and testing sets
    X_train_texts, _, y_train, _ = train_test_split(
        texts, labels, test_size=0.3, random_state=42
    )

    vectorizer = SimpleVectorizer()
    X_train = vectorizer.fit_transform(X_train_texts)

    model = LogisticRegressionScratch(lr=0.1, n_iters=1000)
    model.fit(X_train, y_train)

    # Mapping numeric labels to emotion category names
    emotions = {
        0: "sadness",
        1: "anxiety",
        2: "stress",
        3: "anger",
        4: "exhaustion",
        5: "loneliness",
        6: "happiness"
    }

    return model, vectorizer, emotions, responses

# Function to detect if user input is a greeting
def is_greeting(message):
    """Checks if a message contains a greeting keyword."""
    greetings = ["hi", "hello", "hlo", "hey", "greetings",
                 "good morning", "good afternoon", "good evening", "how are you"]
    message = message.lower().strip()
    return any(greet in message for greet in greetings)

# Predefined chatbot responses for greetings
GREETINGS_RESPONSES = [
    "Hello! How can I help you today?",
    "Hi there! I'm here to listen.",
    "Hey! What's on your mind?",
    "Greetings! How are you feeling today?",
    "Hello! I'm here if you want to talk."
]

# Function to get a chatbot response based on predicted emotion
def get_response(predicted_emotion, responses_dict):
    """
    Returns a random response from the dictionary based on the predicted emotion.
    """
    emotion_key = predicted_emotion.lower()
    if emotion_key in responses_dict:
        return random.choice(responses_dict[emotion_key])
    elif "default" in responses_dict:
        return random.choice(responses_dict["default"])
    else:
        return "I'm here for you."

# Main function to run the chatbot in the console
def main():
    try:
        print("Loading and training the model. This may take a moment...")
        model, vectorizer, emotions, responses = load_and_train()
        print("Model loaded. You can now start chatting.")
        print("Type 'exit' to quit the conversation.")
        print("-" * 30)

        # Main chat loop
        while True:
            user_input = input("You: ")

            if user_input.lower() == 'exit':
                print("Chatbot: Take care of yourself. Goodbye! 💙")
                break

            if not user_input.strip():
                continue

            if is_greeting(user_input):
                print(f"Chatbot: {random.choice(GREETINGS_RESPONSES)}")
            elif contains_crisis_keywords(user_input):
                print(f"Chatbot: {SAFETY_MESSAGE}")
            else:
                vec = vectorizer.transform([user_input])
                pred_label = model.predict(vec)[0]
                predicted_emotion = emotions.get(pred_label, "default")
                reply = get_response(predicted_emotion, responses)
                print(f"Predicted emotion: {predicted_emotion}")
                print(f"Chatbot: {reply}")

    except Exception as e:
        print(f"An error occurred: {e}")
        print("Please ensure all required files are present and the dependencies are installed.")

if __name__ == "__main__":
    main()
